var app = new Vue({ 
    el: '#exercise',
    data: {
        Name: 'Dwight VdV',
        Age: '22',
        Url: 'https://i.kym-cdn.com/photos/images/newsfeed/001/384/535/295.jpg'
    }
});
